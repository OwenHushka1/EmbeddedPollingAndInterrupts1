/*
 * LED_Driver.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */


#include <LED_Driver.h>


static GPIO_Handle_t RedLED;
static GPIO_Handle_t GreenLED;

//Do I still need to add the clock initialization function?
void initializeLED(uint8_t whichLED){

	switch (whichLED){
	  case RED:


		  RedLED.GPIO_PinConfig.PinMode = OUTPUT;
		  RedLED.GPIO_PinConfig.PinPuPdControl = NONE;
		  RedLED.GPIO_PinConfig.PinSpeed = HIGH;
		  RedLED.GPIO_PinConfig.PinNumber = 14;
		  RedLED.GPIO_PinConfig.OPType = PUSHPULL;
		  RedLED.pGPIOx = GPIOG;
		  GPIO_Clock(RedLED.pGPIOx, ENABLE);
		  GPIO_Initialize(&RedLED);

	    	break;

	  case GREEN:
		  GreenLED.GPIO_PinConfig.PinMode = OUTPUT;
		  GreenLED.GPIO_PinConfig.PinSpeed = HIGH;
		  GreenLED.GPIO_PinConfig.PinNumber = 13;
		  GreenLED.GPIO_PinConfig.OPType = PUSHPULL;
		  GreenLED.GPIO_PinConfig.PinPuPdControl = NONE;

		  GreenLED.pGPIOx = GPIOG;
		  GPIO_Clock(GreenLED.pGPIOx, ENABLE);
		  GPIO_Initialize(&GreenLED);
	   		break;

	}
}


void toggleLED(uint8_t whichLED){
	switch (whichLED){
	case RED:
		//GPIO_Toggle(GPIO_RegDef_t *req, uint8_t *pinNumber){
		GPIO_Toggle(RedLED.pGPIOx, RedLED.GPIO_PinConfig.PinNumber);//not certain this is the right pin number
		break;

	case GREEN:
		GPIO_Toggle(GreenLED.pGPIOx, GreenLED.GPIO_PinConfig.PinNumber);
		//GPIO_Toggle(GPIO_RegDef_t *req, uint8_t *pinNumber){
	break;}
}


void disableLED(uint8_t whichLED){

	switch (whichLED){

	case RED:
		GPIO_WriteToInput(RedLED.pGPIOx, &RedLED.GPIO_PinConfig.PinNumber,DISABLE);

		break;

	case GREEN:
		GPIO_WriteToInput(GreenLED.pGPIOx, &GreenLED.GPIO_PinConfig.PinNumber,DISABLE);

		break;


	}

}

void enableLED(uint8_t whichLED){

	switch (whichLED){

	case RED:
		GPIO_WriteToInput(RedLED.pGPIOx, &RedLED.GPIO_PinConfig.PinNumber, ENABLE);

		break;

	case GREEN:
		GPIO_WriteToInput(GreenLED.pGPIOx, &GreenLED.GPIO_PinConfig.PinNumber, ENABLE);

		break;
	}

}
