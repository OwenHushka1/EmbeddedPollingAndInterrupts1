/*
 * GPIO_Driver.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */
#include "GPIO_Driver.h"

void GPIO_Initialize(GPIO_Handle_t *handle){

	uint32_t temp;
	uint32_t altRegister; //upper or lower alternate register
	uint32_t altPinLocation;

	//configuring the port mode
	temp = (handle->GPIO_PinConfig.PinMode << (2 * handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->MODER &= ~(0x3 << (2 * handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->MODER |= temp;


	//check interrupt mode
	if(handle->GPIO_PinConfig.PinInterruptMode!=NO_INTERRUPT){
		//need to configure proper registers within this function
		if(handle->GPIO_PinConfig.PinInterruptMode==FALLING_EDGE){
			EXTI->FTSR|= (1 << handle->GPIO_PinConfig.PinNumber); //set bit in FTSR register
			EXTI->RTSR &=(1 << handle->GPIO_PinConfig.PinNumber); //clear bit in RTSR register

		}
		if(handle->GPIO_PinConfig.PinInterruptMode==RISING_EDGE){
			EXTI->RTSR|= (1 << handle->GPIO_PinConfig.PinNumber); //set bit in RTSR register
			EXTI->FTSR &=(1 << handle->GPIO_PinConfig.PinNumber); //clear bit in FTSR register

		}
		if(handle->GPIO_PinConfig.PinInterruptMode==FALLING_AND_RISING){
			EXTI->RTSR|= (1 << handle->GPIO_PinConfig.PinNumber); //set bit in RTSR register
			EXTI->FTSR |=(1 << handle->GPIO_PinConfig.PinNumber); //set bit in FTSR register
		}

		uint8_t reg = (handle->GPIO_PinConfig.PinNumber)/4;//getting the appropriate register
		uint8_t bitField = (handle->GPIO_PinConfig.PinNumber) %4; //getting the bit field
		uint16_t var = GPIO_GetPortCode(handle->pGPIOx); //getting port number

		APB2_CLK_ENABLE(SYSCFG_BIT);		//enable clock for syscfg
		SYSCFG->EXTIC[reg] &= ~(0xF << (4*bitField));
		SYSCFG->EXTIC[reg] |= var << (4*bitField);



		EXTI->IMR |= (1 << handle->GPIO_PinConfig.PinNumber);//enable interrupt delivery
	}





	//configuring the output speed register
	//clear port mode register pins
	temp = (handle->GPIO_PinConfig.PinSpeed << (2 * handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->OSPEEDR &= ~(0x3 << (2 * handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->OSPEEDR |= temp;


	//configuring pull up/down register
	temp = (handle->GPIO_PinConfig.PinPuPdControl  << (2 * handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->PUPDR &= ~(0x3 << (2 * handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->PUPDR |= temp;



	//configuring output type register

	temp = (handle->GPIO_PinConfig.OPType << (handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->OTYPER &= ~(0x1 << (handle->GPIO_PinConfig.PinNumber));
	handle->pGPIOx->OTYPER |= temp;


	//configuring the alternate function regsiter (if applicable)
	if(handle->GPIO_PinConfig.PinMode == ALTERNATE_FUNCTION){
		altRegister = handle->GPIO_PinConfig.PinNumber/8;
		altPinLocation = handle->GPIO_PinConfig.PinNumber % 8;

		temp = (handle->GPIO_PinConfig.PinAltFunMode << (4 * handle->GPIO_PinConfig.PinNumber));
		handle->pGPIOx->AFR[altRegister] &= ~(0xF << (4 * altPinLocation));
		handle->pGPIOx->AFR[altRegister] |= temp;

	}


}


void GPIO_Clock(GPIO_RegDef_t *req, uint8_t able){

	//decide if enable or disable
	if(able == ENABLE){
		if(req == GPIOA){
			AHB1_CLK_ENABLE(GPIOA_BIT);
		}
		if(req == GPIOG){
			AHB1_CLK_ENABLE(GPIOG_BIT);
		}
	}

	if(able == DISABLE){
		if(req == GPIOA){ //do i need to dereference req here?
			AHB1_CLK_DISABLE(GPIOA_BIT);
		}
		if(req == GPIOG){
			AHB1_CLK_DISABLE(GPIOG_BIT);
		}
	}
}

void GPIO_Toggle(GPIO_RegDef_t *req, uint8_t pinNumber){

	req->ODR ^= (0x1 << pinNumber);
	}



void GPIO_WriteToInput(GPIO_RegDef_t *req, uint8_t *pinNumber, uint8_t val){

	if(val == 1){
		req->ODR |=(0x1<<*pinNumber);
	}
	else{
		req->ODR &= ~(0x1 << *pinNumber);
	}
}


uint8_t GPIO_Read_Input(GPIO_RegDef_t *req, uint8_t pinNumber){
	uint8_t val;
	//capture value from input data register
	val = ((req->IDR >> pinNumber) & 0x01);
	return val;

}

uint16_t GPIO_GetPortCode(GPIO_RegDef_t *req){
	if(req == GPIOA){
		return GPIOA_BIT; //return 0
	}
	else if(req == GPIOG){
		return GPIOG_BIT; //return 6
	}
	return -1;

}

void GPIO_NVIC_INTERRUPT(uint8_t irq_num, uint8_t able){

	if(able == ENABLE){
		IRQ_ENABLE_INTERRUPT(irq_num);
	}
	else{
		IRQ_DISABLE_INTERRUPT(irq_num);
	}
	//prob need to change second variable

}



