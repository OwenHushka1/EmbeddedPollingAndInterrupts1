/*
 * Scheduler.h
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */

#ifndef INC_SCHEDULER_H_
#define INC_SCHEDULER_H_
#include <STM32F429i.h>
#include <stdint.h>


#define DELAY_EVENT (1<<0)
#define LED_TOGGLE_EVENT (1<<1)
#define POLL_BUTTON_EVENT (1<<2)

uint32_t getScheduledEvents();
void addSchedulerEvent(uint32_t event);
void removeSchedulerEvent(uint32_t event);

#endif /* INC_SCHEDULER_H_ */




