/*
 * GPIO_Driver.h
 *
 *  Created on: Sep 5, 2023
 *      Author: Owen Hushka
 */

#ifndef INC_INTERRUPT_CONTROLL_H
#define INC_INTERRUPT_CONTROLL_H

#define EXTI0_IRQ_NUMBER 6
#include "STM32F429i.h"


void IRQ_ENABLE_INTERRUPT(uint8_t IRQ_NUM);
void IRQ_DISABLE_INTERRUPT(uint8_t IRQ_NUM);
void IRQ_CLEAR_INTERRUPT(uint8_t IRQ_NUM);
void IRQ_SET_INTERRUPT(uint8_t  IRQ_NUM);
void EXTI_INTERRUPT_CLEAR(uint8_t pin_num);



#endif /* INC_INTERRUPT_CONTROLL_H */


